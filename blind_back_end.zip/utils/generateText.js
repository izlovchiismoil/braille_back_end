export async function generateText (text) {
    return text;
}